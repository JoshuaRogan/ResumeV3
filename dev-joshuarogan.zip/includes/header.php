<header> 
	<?php require_once("header_nav.php"); ?>
</header> 