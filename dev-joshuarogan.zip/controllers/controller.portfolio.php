<?php 
	$_CONTROLLER = array(); 
	/*******************************Required*******************************/
	$_CONTROLLER["title"]  					= "Josh Rogan | Portfolio"; 
	$_CONTROLLER["header_file"]  			= true;  				//True uses default header
	$_CONTROLLER["footer_file"]				= true; 				//True uses default footer
	/*******************************Required*******************************/
 
	$_CONTROLLER["stylesheets"] 			= array("stylesheet");
	$_CONTROLLER["javascript"] 				= array("index", "scrollReveal/scrollReveal");

	/************DATA HANDLING FUNCTIONS *************/
	$_PAGE = array(); //This is where all of the data for the page will be 

	

?>