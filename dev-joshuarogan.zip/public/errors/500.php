<?php 
	$error_num = 500;
	$error_message = "500 - Internal Server Error";
	require ("error.php");
?>