<?php 
	$error_num = 403;
	$error_message = "403 - Forbidden";
	require ("error.php");
?>