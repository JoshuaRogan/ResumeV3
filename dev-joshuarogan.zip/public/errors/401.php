<?php 
	$error_num = 401;
	$error_message = "401 - Authorization Required";
	require ("error.php");
?>