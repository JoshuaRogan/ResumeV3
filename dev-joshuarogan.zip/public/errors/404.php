<?php 
	$error_num = 404;
	$error_message = "404 - Page Not Found";
	require ("error.php");
?>